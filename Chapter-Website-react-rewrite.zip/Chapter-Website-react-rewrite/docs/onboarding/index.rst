==========
Onboarding
==========

This document goes over the onboarding process
and what you should know to get started

.. toctree::
   :maxdepth: 2

   introduction
   frontend
   backend
   contributing
   faq
