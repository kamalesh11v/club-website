const categories = ["workshop", "general", "talk", "koding kata"];
export default categories;
