# Contributing

Please read the [onboarding guide](https://ucmacm-website.readthedocs.io/en/latest/onboarding/index.html) instead.
